#include <stdlib.h>
#include <time.h>


int main() {
	srand(time(0));
	int a = 0;
	int b = 0;
	for (int i = 0 ; i < 1000000; ++i) {
		double randomic;
	    comeco:
	    	randomic  = rand();
		if (randomic >= 0.75) a++;
		else if (randomic >= 0.5) b++;
		else goto comeco;
	}
}
