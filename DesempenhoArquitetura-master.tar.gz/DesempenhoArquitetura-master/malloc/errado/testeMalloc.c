#include "meuMalloc.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 1000

int main(int argc, char ** argv){

	FILE *dados;

	char *lista[MAX];
	int tam = atoi(argv[1]);

	struct timespec t1, t2;

	long parcial, alocado,aloc_total, media, inter;

	dados = fopen(argv[2],"w");
	iniciaAlocador();

	parcial = 0;
	alocado = 0;
	aloc_total = 0;
	media = 0;

	for(int i = 0; i < MAX; i++) {

		clock_gettime(CLOCK_MONOTONIC_RAW, &t1);
		lista[i] = meuMalloc(tam);
		clock_gettime(CLOCK_MONOTONIC_RAW, &t2);
		inter = t2.tv_nsec - t1.tv_nsec;
		alocado += tam;
		aloc_total += tam + 24;
		//fprintf(dados,"%ld,%ld,%ld, %ld\n", inter, alocado, aloc_total, aloc_total % 4096);
		fprintf(dados,"%ld\n", inter);
		parcial += inter;
		//imprimeMapa_alt();
	}

	media = parcial/MAX;
	fprintf(dados,"\n%ld\n", media);

	finalizaAlocador();
	return 0;
}
