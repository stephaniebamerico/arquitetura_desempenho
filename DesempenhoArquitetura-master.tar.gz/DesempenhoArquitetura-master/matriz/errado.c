#include <stdio.h>
#include <stdlib.h>
#include <likwid.h>

int main(int argc, char const *argv[]) {
	LIKWID_MARKER_INIT;
	int num = atoi(argv[1]);
	int *matriz = malloc (sizeof(int)*num*num);

	LIKWID_MARKER_START("matriz");
    for (int j = 0; j < num; ++j) {
        for (int i = 0; i < num; ++i) {
            matriz[i*num+j] = i;
        }
    }
	LIKWID_MARKER_STOP("matriz");

	free(matriz);

	LIKWID_MARKER_CLOSE;
    return 0;
}
