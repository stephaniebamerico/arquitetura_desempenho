rm aux/*


for (( i = 0; i < 100; i++ )); do
	errado/testeMalloc 10000 "dados/e_10k_${i}"
done

cat dados/e_10k_0 > aux/aux_0

for (( i = 1; i < 100; i++ )); do
	while true
	do
		read -r f1 <&3 || break
		read -r f2 <&4 || break
		echo "${f1},${f2}" >> aux/aux_$i
	done 3< aux/aux_$((i-1)) 4< dados/e_10k_$i
done

cp aux/aux_99 .
mv aux_99 dados/concat_e_10k

rm aux/*

for (( i = 0; i < 100; i++ )); do
	certo/testeMalloc 10000 "dados/c_10k_${i}"
done

cat dados/c_10k_0 > aux/aux_0

for (( i = 1; i < 100; i++ )); do
	while true
	do
		read -r f1 <&3 || break
		read -r f2 <&4 || break
		echo "${f1},${f2}" >> aux/aux_$i
	done 3< aux/aux_$((i-1)) 4< dados/c_10k_$i
done

cp aux/aux_99 .
mv aux_99 dados/concat_c_10k

while true
do
	read -r f1 <&3 || break
	read -r f2 <&4 || break
	echo "${f1},,,${f2}" >> dados/concat_c_e_10k
done 3< dados/concat_e_10k 4< dados/concat_c_10k
