#!/bin/bash

make clean
make

for i in 100 1000 10000 ; do
	for group in L3 L3CACHE L2 L2CACHE TLB_DATA TLB_INSTR; do 
		likwid-perfctr -C 3 -f -g $group -m ./certo $i > ${i}N${group}_certo
		likwid-perfctr -C 3 -f -g $group -m ./errado $i > ${i}N${group}_errado
	done
done

FILE=l3band_dados
echo -n "" > $FILE
for i in 100 1000 10000; do
	echo -n "$i " >> $FILE
	WRITE="$(grep "L3 band" ${i}NL3_certo | awk -F '|' '{print $3}') $(grep "L3 band" ${i}NL3_errado | awk -F '|' '{print $3}')"
	echo $WRITE >> $FILE
done

FILE=l2band_dados
echo -n "" > $FILE
for i in 100 1000 10000 ; do
	echo -n "$i " >> $FILE
	WRITE="$(grep "L2 band" ${i}NL2_certo | awk -F '|' '{print $3}') $(grep "L2 band" ${i}NL2_errado | awk -F '|' '{print $3}')"
	echo $WRITE >> $FILE
done

FILE=l3miss_dados
echo -n "" > $FILE
for i in 100 1000 10000 ; do
	echo -n "$i " >> $FILE
	WRITE="$(grep "L3 miss ratio" ${i}NL3CACHE_certo | awk -F '|' '{print $3}') $(grep "L3 miss ratio" ${i}NL3CACHE_errado | awk -F '|' '{print $3}')"
	echo $WRITE >> $FILE
done

FILE=l2miss_dados
echo -n "" > $FILE
for i in 100 1000 10000 ; do
	echo -n "$i " >> $FILE
	WRITE="$(grep "L2 miss ratio" ${i}NL2CACHE_certo | awk -F '|' '{print $3}') $(grep "L2 miss ratio" ${i}NL2CACHE_errado | awk -F '|' '{print $3}')"
	echo $WRITE >> $FILE
done

FILE=tlbdata_dados
echo -n "" > $FILE
for i in 100 1000 10000 ; do
	echo -n "$i " >> $FILE
	WRITE="$(grep "miss ratio" ${i}NTLB_DATA_certo | awk -F '|' '{print $3}') $(grep "store misses" ${i}NTLB_DATA_errado | awk -F '|' '{print $3}')"
	echo $WRITE >> $FILE
done

FILE=tlbinstr_dados
echo -n "" > $FILE
for i in 100 1000 10000 ; do
	echo -n "$i " >> $FILE
	WRITE="$(grep "load misses" ${i}NTLB_INSTR_certo | awk -F '|' '{print $3}') $(grep "ITLB misses" ${i}NTLB_INSTR_errado | awk -F '|' '{print $3}')"
	echo $WRITE >> $FILE
done

gnuplot makeGraphs.plot
